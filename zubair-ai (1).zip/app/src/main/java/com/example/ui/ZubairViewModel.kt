package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.api.Content
import com.example.api.GenerateContentRequest
import com.example.api.Part
import com.example.api.RetrofitClient
import com.example.api.GenerationConfig
import com.example.data.*
import com.example.BuildConfig
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

data class ChatMessage(
    val sender: String, // "user" or "zubair_ai"
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class QuizQuestion(
    val question: String,
    val options: List<String>,
    val correctAnswerIndex: Int,
    val explanation: String
)

class ZubairViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: AppRepository

    init {
        val db = AppDatabase.getDatabase(application)
        repository = AppRepository(db)
    }

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    private val todayDateStr = dateFormat.format(Date())

    // UI States observed by Compose
    val tasks: StateFlow<List<Task>> = repository.allTasks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notes: StateFlow<List<Note>> = repository.allNotes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val exerciseLogs: StateFlow<List<ExerciseLog>> = repository.allExerciseLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val currentDietLog: StateFlow<DietLog?> = repository.getDietLogByDate(todayDateStr)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val learningLogs: StateFlow<List<LearningLog>> = repository.allLearningLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // AI Chat state
    private val _chatHistory = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(
                "zubair_ai",
                "Assalam-o-Alaikum, Zubair! I am your personal AI operating system. I'm ready to manage your routine, tracks, gym, and learning. How can I assist you today?"
            )
        )
    )
    val chatHistory: StateFlow<List<ChatMessage>> = _chatHistory.asStateFlow()

    private val _isChatLoading = MutableStateFlow(false)
    val isChatLoading: StateFlow<Boolean> = _isChatLoading.asStateFlow()

    // Dashboard AI Suggestion
    private val _aiSuggestion = MutableStateFlow("Tap 'Refresh AI Advice' to scan your tasks and get tailored daily guidance from Zubair AI.")
    val aiSuggestion: StateFlow<String> = _aiSuggestion.asStateFlow()

    private val _isGeneratingSuggestion = MutableStateFlow(false)
    val isGeneratingSuggestion: StateFlow<Boolean> = _isGeneratingSuggestion.asStateFlow()

    // Pomodoro Timer States
    private val _pomodoroSecondsLeft = MutableStateFlow(1500) // 25 mins
    val pomodoroSecondsLeft: StateFlow<Int> = _pomodoroSecondsLeft.asStateFlow()

    private val _isPomodoroRunning = MutableStateFlow(false)
    val isPomodoroRunning: StateFlow<Boolean> = _isPomodoroRunning.asStateFlow()

    private val _pomodoroMode = MutableStateFlow("Work") // "Work" or "Break"
    val pomodoroMode: StateFlow<String> = _pomodoroMode.asStateFlow()

    private var pomodoroJob: Job? = null

    // Quiz States
    private val _currentQuizQuestions = MutableStateFlow<List<QuizQuestion>>(emptyList())
    val currentQuizQuestions: StateFlow<List<QuizQuestion>> = _currentQuizQuestions.asStateFlow()

    private val _quizTopic = MutableStateFlow("Flutter")
    val quizTopic: StateFlow<String> = _quizTopic.asStateFlow()

    // Language setting
    private val _appLanguage = MutableStateFlow("English/Urdu")
    val appLanguage: StateFlow<String> = _appLanguage.asStateFlow()

    init {
        // Initialize today's diet log if it doesn't exist
        viewModelScope.launch {
            val existing = repository.getDietLogByDateSync(todayDateStr)
            if (existing == null) {
                repository.insertOrUpdateDietLog(DietLog(date = todayDateStr))
            }
        }
        loadOfflineQuizzes("Flutter")
    }

    // --- Task Actions ---
    fun addTask(title: String, category: String, priority: String) {
        viewModelScope.launch {
            repository.insertTask(Task(title = title, category = category, priority = priority))
        }
    }

    fun toggleTaskCompletion(task: Task) {
        viewModelScope.launch {
            repository.updateTask(task.copy(isCompleted = !task.isCompleted))
        }
    }

    fun deleteTask(task: Task) {
        viewModelScope.launch {
            repository.deleteTask(task)
        }
    }

    // --- Note Actions ---
    fun addNote(title: String, content: String, category: String) {
        viewModelScope.launch {
            repository.insertNote(Note(title = title, content = content, category = category))
        }
    }

    fun deleteNote(note: Note) {
        viewModelScope.launch {
            repository.deleteNote(note)
        }
    }

    // --- Gym Actions ---
    fun logWorkout(exerciseName: String, muscleGroup: String, sets: Int, reps: Int, weight: Double, restSeconds: Int) {
        viewModelScope.launch {
            repository.insertExerciseLog(
                ExerciseLog(
                    exerciseName = exerciseName,
                    muscleGroup = muscleGroup,
                    sets = sets,
                    reps = reps,
                    weight = weight,
                    restTimer = restSeconds
                )
            )
        }
    }

    fun deleteWorkout(log: ExerciseLog) {
        viewModelScope.launch {
            repository.deleteExerciseLog(log)
        }
    }

    // --- Diet & Water Actions ---
    fun addCalories(amount: Int) {
        viewModelScope.launch {
            val current = repository.getDietLogByDateSync(todayDateStr) ?: DietLog(date = todayDateStr)
            repository.insertOrUpdateDietLog(current.copy(calories = (current.calories + amount).coerceAtLeast(0)))
        }
    }

    fun addProtein(amount: Int) {
        viewModelScope.launch {
            val current = repository.getDietLogByDateSync(todayDateStr) ?: DietLog(date = todayDateStr)
            repository.insertOrUpdateDietLog(current.copy(protein = (current.protein + amount).coerceAtLeast(0)))
        }
    }

    fun addWater(amountMl: Int) {
        viewModelScope.launch {
            val current = repository.getDietLogByDateSync(todayDateStr) ?: DietLog(date = todayDateStr)
            repository.insertOrUpdateDietLog(current.copy(waterIntake = (current.waterIntake + amountMl).coerceAtLeast(0)))
        }
    }

    // --- Pomodoro Actions ---
    fun startPomodoro() {
        if (_isPomodoroRunning.value) return
        _isPomodoroRunning.value = true
        pomodoroJob = viewModelScope.launch {
            while (_pomodoroSecondsLeft.value > 0) {
                delay(1000)
                _pomodoroSecondsLeft.value -= 1
            }
            // Switch modes when timer hits zero
            if (_pomodoroMode.value == "Work") {
                _pomodoroMode.value = "Break"
                _pomodoroSecondsLeft.value = 300 // 5 min break
            } else {
                _pomodoroMode.value = "Work"
                _pomodoroSecondsLeft.value = 1500 // 25 min work
            }
            _isPomodoroRunning.value = false
        }
    }

    fun pausePomodoro() {
        _isPomodoroRunning.value = false
        pomodoroJob?.cancel()
    }

    fun resetPomodoro() {
        _isPomodoroRunning.value = false
        pomodoroJob?.cancel()
        _pomodoroMode.value = "Work"
        _pomodoroSecondsLeft.value = 1500
    }

    // --- Language Action ---
    fun setAppLanguage(lang: String) {
        _appLanguage.value = lang
    }

    // --- AI Chat Actions ---
    fun sendMessage(userText: String) {
        if (userText.trim().isEmpty()) return

        val userMessage = ChatMessage("user", userText)
        _chatHistory.value = _chatHistory.value + userMessage
        _isChatLoading.value = true

        viewModelScope.launch {
            val promptContext = buildChatPromptContext(userText)
            val reply = queryGemini(promptContext, systemInstruction = "You are Zubair AI, a personalized AI operating system. Speak like an exceptionally intelligent, supportive personal OS companion. Respond in Roman Urdu, Urdu or English seamlessly depending on what Zubair uses. Always be highly precise, friendly, and practical.")
            _chatHistory.value = _chatHistory.value + ChatMessage("zubair_ai", reply)
            _isChatLoading.value = false
        }
    }

    // --- AI Dashboard Suggestions ---
    fun refreshAiSuggestions() {
        _isGeneratingSuggestion.value = true
        viewModelScope.launch {
            val pendingTasksList = tasks.value.filter { !it.isCompleted }.joinToString { "${it.title} (Priority: ${it.priority})" }
            val waterStr = "${currentDietLog.value?.waterIntake ?: 0} ml"
            val calorieStr = "${currentDietLog.value?.calories ?: 0} kcal"
            val workoutsList = exerciseLogs.value.take(3).joinToString { "${it.exerciseName} on ${it.muscleGroup}" }

            val prompt = """
                Generate a sharp, encouraging, action-oriented 2-sentence morning guidance (Assalam-o-Alaikum, Zubair!) based on:
                Pending Tasks: $pendingTasksList
                Water Intake: $waterStr
                Calories: $calorieStr
                Recent Exercises: $workoutsList
                Current Local Time: 2026-06-30T10:22:14.
                Focus on Roman Urdu/English mix or clean Urdu text. Ensure it is highly practical and personal.
            """.trimIndent()

            val suggestion = queryGemini(prompt, systemInstruction = "You are Zubair AI. Speak directly and encouragingly to Zubair.")
            _aiSuggestion.value = suggestion
            _isGeneratingSuggestion.value = false
        }
    }

    // Helper to query Gemini API directly
    private suspend fun queryGemini(prompt: String, systemInstruction: String): String {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY" || apiKey == "GEMINI_API_KEY") {
            // Graceful Offline Fallback
            delay(1000)
            return getOfflineFallbackAdvice()
        }

        val request = GenerateContentRequest(
            contents = listOf(Content(parts = listOf(Part(text = prompt)))),
            systemInstruction = Content(parts = listOf(Part(text = systemInstruction))),
            generationConfig = GenerationConfig(temperature = 0.7, maxOutputTokens = 1024)
        )

        return try {
            val response = RetrofitClient.geminiService.generateContent(apiKey, request)
            response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text 
                ?: "I am with you, Zubair. Let's conquer our targets today offline-first!"
        } catch (e: Exception) {
            "Conquered offline mode! Stay hydrated and keep building, Zubair. Heuristics are green."
        }
    }

    private fun getOfflineFallbackAdvice(): String {
        val advices = listOf(
            "Assalam-o-Alaikum Zubair! Keep code clean and water flowing. Today is a great day to smash your gym targets!",
            "Zubair, remember that persistence beats talent. Focus on 25 minutes of deep work on Android right now.",
            "Water logged! Keep it up. Your muscles need hydration to recover from those heavy gym lifts.",
            "Great routine tracking. Let's finish your pending tasks before sunset!"
        )
        return advices.random()
    }

    private fun buildChatPromptContext(latestMessage: String): String {
        // Send past 4 messages for conversational context preservation
        val historySnippet = chatHistory.value.takeLast(4).joinToString("\n") { 
            "${if (it.sender == "user") "Zubair" else "Zubair AI"}: ${it.text}"
        }
        return "$historySnippet\nZubair: $latestMessage\nZubair AI:"
    }

    // --- Quiz Actions & Heuristics ---
    fun selectQuizTopic(topic: String) {
        _quizTopic.value = topic
        loadOfflineQuizzes(topic)
    }

    fun logQuizResult(topic: String, score: Int, total: Int) {
        viewModelScope.launch {
            repository.insertLearningLog(
                LearningLog(
                    topic = topic,
                    studyMinutes = 15, // default session weight
                    quizScore = score,
                    quizTotal = total
                )
            )
        }
    }

    private fun loadOfflineQuizzes(topic: String) {
        _currentQuizQuestions.value = when (topic) {
            "Flutter" -> listOf(
                QuizQuestion(
                    "What is a StatefulWidget in Flutter?",
                    listOf("A widget that can change its state dynamically during runtime", "A completely immutable stateless structural card", "A server-side API integration class", "A database engine"),
                    0,
                    "StatefulWidgets maintain active State objects which allow dynamic redrawing on state mutations."
                ),
                QuizQuestion(
                    "How does Riverpod differ from Provider?",
                    listOf("It compiles to machine code", "It does not depend on the Flutter widget tree and is compile-safe", "It can only run in Dart background isolates", "It is purely for local UI navigation"),
                    1,
                    "Riverpod avoids dynamic Context lookups, offering static compile-time safety and decoupled providers."
                ),
                QuizQuestion(
                    "Which method is called when a stateful widget's state is disposed?",
                    listOf("initState()", "build()", "dispose()", "setState()"),
                    2,
                    "dispose() is called to release hardware resources, streams, controllers, and clean up active loops."
                )
            )
            "Android Development" -> listOf(
                QuizQuestion(
                    "What is the recommended modern database framework in Android?",
                    listOf("SharedPreferences", "SQLite raw cursor wrapper", "Room Persistence Library", "Firebase Realtime Cache"),
                    2,
                    "Room is a Material-friendly M3 SQLite mapping library recommended by Google, offering compile-time query checking."
                ),
                QuizQuestion(
                    "What does enableEdgeToEdge() do in Jetpack Compose?",
                    listOf("It increases memory allocations", "It enables the application to draw behind system bars (status & navigation)", "It crops circular custom widgets", "It runs continuous automated tests"),
                    1,
                    "enableEdgeToEdge() lets your app fill the full screen bleed, overlaying content elegantly beneath status bars."
                )
            )
            "AI" -> listOf(
                QuizQuestion(
                    "What is a System Instruction in generative model prompts?",
                    listOf("A low-level system process compiler flag", "Rules and persona parameters set beforehand to guide model responses", "An image scaling filter coefficient", "A local background loop timer"),
                    1,
                    "System Instructions let you safely configure assistant behavior, styles, boundaries, and specific output structures."
                )
            )
            else -> listOf(
                QuizQuestion(
                    "What represents offline-first design philosophy?",
                    listOf("Relying purely on cloud APIs", "Storing all personal data locally in a robust database like Room and syncing only optionally", "Disabling internet permissions in AndroidManifest", "Never writing custom UI code"),
                    1,
                    "Offline-first prioritizes local state persistence, ensuring zero latency, maximum privacy, and unbroken utility."
                )
            )
        }
    }
}
