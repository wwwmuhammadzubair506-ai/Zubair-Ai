package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = CosmicCyan,
    secondary = CardBorderNavy,
    tertiary = CosmicGold,
    background = SpaceNavy,
    surface = CardNavy,
    onPrimary = Color.Black,
    onSecondary = SlateLight,
    onTertiary = Color.Black,
    onBackground = SlateWhite,
    onSurface = SlateLight
)

private val LightColorScheme = lightColorScheme(
    primary = CosmicCyan,
    secondary = CardBorderNavy,
    tertiary = CosmicGold,
    background = SpaceNavy, // Maintain dark aesthetic for OS look
    surface = CardNavy,
    onPrimary = Color.Black,
    onSecondary = SlateLight,
    onTertiary = Color.Black,
    onBackground = SlateWhite,
    onSurface = SlateLight
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Disable dynamic colors to preserve our tailored branding
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
