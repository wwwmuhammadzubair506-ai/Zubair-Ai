package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CosmicCyan = Color(0xFF00F2FE)
val CosmicGold = Color(0xFFFFD700)
val CosmicPurple = Color(0xFFB388FF)

val SpaceNavy = Color(0xFF070A13)
val CardNavy = Color(0xFF10172A)
val CardBorderNavy = Color(0xFF1E293B)

val SlateWhite = Color(0xFFF8FAFC)
val SlateLight = Color(0xFFE2E8F0)
val SlateGray = Color(0xFF94A3B8)
