package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity(tableName = "tasks")
data class Task(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val category: String = "Routine", // e.g., "Routine", "Tasks", "Calendar", "Shopping"
    val dueDate: Long = System.currentTimeMillis(),
    val isCompleted: Boolean = false,
    val priority: String = "Medium" // "High", "Medium", "Low"
) : Serializable

@Entity(tableName = "notes")
data class Note(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val content: String,
    val category: String = "General", // "General", "Journal", "Project", "Idea"
    val timestamp: Long = System.currentTimeMillis()
) : Serializable

@Entity(tableName = "exercise_logs")
data class ExerciseLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val exerciseName: String,
    val muscleGroup: String, // e.g., "Chest", "Back", "Legs", "Shoulders", "Arms"
    val sets: Int,
    val reps: Int,
    val weight: Double,
    val restTimer: Int = 60, // in seconds
    val timestamp: Long = System.currentTimeMillis()
) : Serializable

@Entity(tableName = "diet_logs")
data class DietLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val date: String, // e.g., "yyyy-MM-dd"
    val calories: Int = 0,
    val protein: Int = 0, // in grams
    val carbs: Int = 0, // in grams
    val fat: Int = 0, // in grams
    val waterIntake: Int = 0 // in ml
) : Serializable

@Entity(tableName = "learning_logs")
data class LearningLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val topic: String, // e.g., "Flutter", "AI", "Android", "Programming", "English"
    val studyMinutes: Int = 0,
    val quizScore: Int = -1, // -1 means no quiz taken yet
    val quizTotal: Int = -1,
    val timestamp: Long = System.currentTimeMillis()
) : Serializable
