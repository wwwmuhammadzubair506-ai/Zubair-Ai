package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface TaskDao {
    @Query("SELECT * FROM tasks ORDER BY dueDate ASC")
    fun getAllTasks(): Flow<List<Task>>

    @Query("SELECT * FROM tasks WHERE category = :category ORDER BY dueDate ASC")
    fun getTasksByCategory(category: String): Flow<List<Task>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: Task)

    @Update
    suspend fun updateTask(task: Task)

    @Delete
    suspend fun deleteTask(task: Task)

    @Query("DELETE FROM tasks WHERE id = :id")
    suspend fun deleteTaskById(id: Int)
}

@Dao
interface NoteDao {
    @Query("SELECT * FROM notes ORDER BY timestamp DESC")
    fun getAllNotes(): Flow<List<Note>>

    @Query("SELECT * FROM notes WHERE category = :category ORDER BY timestamp DESC")
    fun getNotesByCategory(category: String): Flow<List<Note>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: Note)

    @Delete
    suspend fun deleteNote(note: Note)
}

@Dao
interface ExerciseLogDao {
    @Query("SELECT * FROM exercise_logs ORDER BY timestamp DESC")
    fun getAllExerciseLogs(): Flow<List<ExerciseLog>>

    @Query("SELECT * FROM exercise_logs WHERE muscleGroup = :muscleGroup ORDER BY timestamp DESC")
    fun getLogsByMuscleGroup(muscleGroup: String): Flow<List<ExerciseLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: ExerciseLog)

    @Delete
    suspend fun deleteLog(log: ExerciseLog)
}

@Dao
interface DietLogDao {
    @Query("SELECT * FROM diet_logs WHERE date = :date LIMIT 1")
    fun getLogByDate(date: String): Flow<DietLog?>

    @Query("SELECT * FROM diet_logs WHERE date = :date LIMIT 1")
    suspend fun getLogByDateSync(date: String): DietLog?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateLog(log: DietLog)
}

@Dao
interface LearningLogDao {
    @Query("SELECT * FROM learning_logs ORDER BY timestamp DESC")
    fun getAllLearningLogs(): Flow<List<LearningLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: LearningLog)
}
