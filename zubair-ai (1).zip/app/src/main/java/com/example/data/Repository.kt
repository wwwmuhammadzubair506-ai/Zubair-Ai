package com.example.data

import kotlinx.coroutines.flow.Flow

class AppRepository(private val db: AppDatabase) {
    private val taskDao = db.taskDao()
    private val noteDao = db.noteDao()
    private val exerciseLogDao = db.exerciseLogDao()
    private val dietLogDao = db.dietLogDao()
    private val learningLogDao = db.learningLogDao()

    // Tasks
    val allTasks: Flow<List<Task>> = taskDao.getAllTasks()
    fun getTasksByCategory(category: String): Flow<List<Task>> = taskDao.getTasksByCategory(category)
    suspend fun insertTask(task: Task) = taskDao.insertTask(task)
    suspend fun updateTask(task: Task) = taskDao.updateTask(task)
    suspend fun deleteTask(task: Task) = taskDao.deleteTask(task)
    suspend fun deleteTaskById(id: Int) = taskDao.deleteTaskById(id)

    // Notes
    val allNotes: Flow<List<Note>> = noteDao.getAllNotes()
    fun getNotesByCategory(category: String): Flow<List<Note>> = noteDao.getNotesByCategory(category)
    suspend fun insertNote(note: Note) = noteDao.insertNote(note)
    suspend fun deleteNote(note: Note) = noteDao.deleteNote(note)

    // Exercise Logs
    val allExerciseLogs: Flow<List<ExerciseLog>> = exerciseLogDao.getAllExerciseLogs()
    fun getLogsByMuscleGroup(group: String): Flow<List<ExerciseLog>> = exerciseLogDao.getLogsByMuscleGroup(group)
    suspend fun insertExerciseLog(log: ExerciseLog) = exerciseLogDao.insertLog(log)
    suspend fun deleteExerciseLog(log: ExerciseLog) = exerciseLogDao.deleteLog(log)

    // Diet Logs
    fun getDietLogByDate(date: String): Flow<DietLog?> = dietLogDao.getLogByDate(date)
    suspend fun getDietLogByDateSync(date: String): DietLog? = dietLogDao.getLogByDateSync(date)
    suspend fun insertOrUpdateDietLog(log: DietLog) = dietLogDao.insertOrUpdateLog(log)

    // Learning Logs
    val allLearningLogs: Flow<List<LearningLog>> = learningLogDao.getAllLearningLogs()
    suspend fun insertLearningLog(log: LearningLog) = learningLogDao.insertLog(log)
}
