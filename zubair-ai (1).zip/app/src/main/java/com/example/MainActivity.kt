package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.*
import com.example.ui.ChatMessage
import com.example.ui.QuizQuestion
import com.example.ui.ZubairViewModel
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    contentWindowInsets = WindowInsets.safeDrawing
                ) { innerPadding ->
                    MainCockpitScreen(
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun MainCockpitScreen(
    modifier: Modifier = Modifier,
    viewModel: ZubairViewModel = viewModel()
) {
    var currentTab by remember { mutableStateOf(0) }
    var showSettingsDialog by remember { mutableStateOf(false) }

    val appLanguage by viewModel.appLanguage.collectAsStateWithLifecycle()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // High-End Header with live-ticking feel, branding, and setting trigger
            HeaderSection(
                onSettingsClicked = { showSettingsDialog = true },
                appLanguage = appLanguage
            )

            // Primary sliding view space
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                when (currentTab) {
                    0 -> DashboardView(viewModel = viewModel)
                    1 -> AiChatView(viewModel = viewModel)
                    2 -> PlannerNotesView(viewModel = viewModel)
                    3 -> GymDietView(viewModel = viewModel)
                    4 -> LearningQuizView(viewModel = viewModel)
                }
            }

            // Bottom Navigation Bar with Standard M3 Pills and consistent spacing
            BottomNavigationBar(
                activeTab = currentTab,
                onTabSelected = { currentTab = it }
            )
        }

        // Settings Dialog Trigger
        if (showSettingsDialog) {
            SettingsDialog(
                currentLanguage = appLanguage,
                onDismiss = { showSettingsDialog = false },
                onLanguageChanged = { viewModel.setAppLanguage(it) }
            )
        }
    }
}

// --- Common UI Components ---

@Composable
fun HeaderSection(
    onSettingsClicked: () -> Unit,
    appLanguage: String
) {
    val dateStr = remember {
        val formatter = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault())
        formatter.format(Date())
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(130.dp)
    ) {
        // Hero Background illustration loaded from generate_image
        Image(
            painter = painterResource(id = R.drawable.img_dashboard_hero),
            contentDescription = "Cosmic Neuromorphic Wave",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        // Overlay Gradient for readability and dark blending
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color.Transparent, Color(0xFF070A13).copy(alpha = 0.95f))
                    )
                )
        )

        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.Bottom,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "Assalam-o-Alaikum, Zubair!",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = dateStr,
                    fontSize = 12.sp,
                    color = Color.White.copy(alpha = 0.7f)
                )
            }

            IconButton(
                onClick = onSettingsClicked,
                modifier = Modifier
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.4f))
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "System Settings",
                    tint = MaterialTheme.colorScheme.tertiary
                )
            }
        }
    }
}

@Composable
fun BottomNavigationBar(
    activeTab: Int,
    onTabSelected: (Int) -> Unit
) {
    NavigationBar(
        containerColor = Color(0xFF10172A),
        tonalElevation = 8.dp,
        windowInsets = WindowInsets.navigationBars
    ) {
        val items = listOf(
            Triple("Cockpit", Icons.Default.Home, 0),
            Triple("Zubair AI", Icons.Default.Email, 1),
            Triple("Planner", Icons.Default.Edit, 2),
            Triple("Gym", Icons.Default.Star, 3),
            Triple("Study", Icons.Default.Build, 4)
        )

        items.forEach { (label, icon, index) ->
            NavigationBarItem(
                selected = activeTab == index,
                onClick = { onTabSelected(index) },
                icon = { Icon(imageVector = icon, contentDescription = label) },
                label = { Text(label, fontSize = 10.sp) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Color.Black,
                    selectedTextColor = MaterialTheme.colorScheme.primary,
                    indicatorColor = MaterialTheme.colorScheme.primary,
                    unselectedIconColor = Color.White.copy(alpha = 0.5f),
                    unselectedTextColor = Color.White.copy(alpha = 0.5f)
                )
            )
        }
    }
}

// --- Tab 0: Dashboard (Home) ---

@Composable
fun DashboardView(viewModel: ZubairViewModel) {
    val tasks by viewModel.tasks.collectAsStateWithLifecycle()
    val dietLog by viewModel.currentDietLog.collectAsStateWithLifecycle()
    val aiSuggestion by viewModel.aiSuggestion.collectAsStateWithLifecycle()
    val isGenerating by viewModel.isGeneratingSuggestion.collectAsStateWithLifecycle()

    val pendingTasks = tasks.filter { !it.isCompleted }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Live Pomodoro Floating Widget
        item { PomodoroWidget(viewModel = viewModel) }

        // 2. AI Suggestions Panel with Direct Refresh
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF111E36)),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Email,
                                contentDescription = "Zubair AI Suggestions",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Zubair AI Suggestions",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        IconButton(
                            onClick = { viewModel.refreshAiSuggestions() },
                            modifier = Modifier.testTag("refresh_ai_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Scan and Refresh Suggestions",
                                tint = MaterialTheme.colorScheme.tertiary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    if (isGenerating) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(60.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                        }
                    } else {
                        Text(
                            text = aiSuggestion,
                            fontSize = 13.sp,
                            color = Color.White.copy(alpha = 0.9f),
                            lineHeight = 18.sp
                        )
                    }
                }
            }
        }

        // 3. Quick Stats / Macros Logger
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF10172A))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Daily Fuel & Hydration Tracker",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.tertiary
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // Hydration Progress
                    val currentWater = dietLog?.waterIntake ?: 0
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Water Intake", fontSize = 13.sp, color = Color.White)
                            Text("$currentWater / 3000 ml", fontSize = 11.sp, color = Color.White.copy(alpha = 0.6f))
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { viewModel.addWater(250) },
                                modifier = Modifier.testTag("log_water_button"),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B))
                            ) {
                                Text("+250ml", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                    LinearProgressIndicator(
                        progress = { (currentWater / 3000f).coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = MaterialTheme.colorScheme.primary,
                        trackColor = Color(0xFF1E293B)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Diet Calories Progress
                    val currentCalories = dietLog?.calories ?: 0
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Energy Log", fontSize = 13.sp, color = Color.White)
                            Text("$currentCalories kcal", fontSize = 11.sp, color = Color.White.copy(alpha = 0.6f))
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { viewModel.addCalories(100) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B))
                            ) {
                                Text("+100kcal", fontSize = 11.sp, color = MaterialTheme.colorScheme.tertiary)
                            }
                            Button(
                                onClick = { viewModel.addCalories(500) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B))
                            ) {
                                Text("+500kcal", fontSize = 11.sp, color = MaterialTheme.colorScheme.tertiary)
                            }
                        }
                    }
                }
            }
        }

        // 4. Pending Tasks Summary
        item {
            Text(
                text = "Today's Priorities (${pendingTasks.size})",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = SlateLight,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        if (pendingTasks.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF161D30))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Zero pending tasks. Excellent routine management, Zubair!",
                            color = Color.White.copy(alpha = 0.6f),
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        } else {
            items(pendingTasks) { task ->
                TaskRow(task = task, onCheckedChange = { viewModel.toggleTaskCompletion(task) })
            }
        }
    }
}

@Composable
fun PomodoroWidget(viewModel: ZubairViewModel) {
    val secondsLeft by viewModel.pomodoroSecondsLeft.collectAsStateWithLifecycle()
    val isRunning by viewModel.isPomodoroRunning.collectAsStateWithLifecycle()
    val mode by viewModel.pomodoroMode.collectAsStateWithLifecycle()

    val minutes = secondsLeft / 60
    val seconds = secondsLeft % 60
    val timeStr = String.format("%02d:%02d", minutes, seconds)

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E2F)),
        border = BorderStroke(1.dp, Color(0xFF4A4A6A))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Focus Mode: $mode",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = timeStr,
                    fontSize = 28.sp,
                    color = Color.White,
                    fontWeight = FontWeight.ExtraBold
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (isRunning) {
                    IconButton(
                        onClick = { viewModel.pausePomodoro() },
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(Color.Red.copy(alpha = 0.2f))
                    ) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Pause", tint = Color.Red)
                    }
                } else {
                    IconButton(
                        onClick = { viewModel.startPomodoro() },
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.2f))
                    ) {
                        Icon(imageVector = Icons.Default.PlayArrow, contentDescription = "Start", tint = MaterialTheme.colorScheme.primary)
                    }
                }

                IconButton(
                    onClick = { viewModel.resetPomodoro() },
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.1f))
                ) {
                    Icon(imageVector = Icons.Default.Refresh, contentDescription = "Reset", tint = Color.White)
                }
            }
        }
    }
}

// --- Tab 1: AI Chat (Zubair AI) ---

@Composable
fun AiChatView(viewModel: ZubairViewModel) {
    val chatHistory by viewModel.chatHistory.collectAsStateWithLifecycle()
    val isLoading by viewModel.isChatLoading.collectAsStateWithLifecycle()

    var textInput by remember { mutableStateOf("") }
    val listState = rememberScrollState()

    // Auto scroll chat list down
    LaunchedEffect(chatHistory.size) {
        listState.animateScrollTo(listState.maxValue)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Instructions Badge
        Card(
            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1B233A))
        ) {
            Text(
                text = "💡 Ask about Flutter, Gym plans, Diet macros, English revision, or type in Roman Urdu!",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.tertiary,
                modifier = Modifier.padding(8.dp),
                textAlign = TextAlign.Center
            )
        }

        // Messages Area
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(listState)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                chatHistory.forEach { msg ->
                    ChatBubble(message = msg)
                }

                if (isLoading) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        CircularProgressIndicator(
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Input Control Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextField(
                value = textInput,
                onValueChange = { textInput = it },
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(24.dp)),
                placeholder = { Text("Command Zubair AI...", fontSize = 14.sp) },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color(0xFF1E293B),
                    unfocusedContainerColor = Color(0xFF1E293B),
                    disabledContainerColor = Color(0xFF1E293B),
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent
                ),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = {
                    if (textInput.isNotBlank()) {
                        viewModel.sendMessage(textInput)
                        textInput = ""
                    }
                })
            )

            Spacer(modifier = Modifier.width(8.dp))

            IconButton(
                onClick = {
                    if (textInput.isNotBlank()) {
                        viewModel.sendMessage(textInput)
                        textInput = ""
                    }
                },
                modifier = Modifier
                    .testTag("send_chat_button")
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary)
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Send prompt",
                    tint = Color.Black
                )
            }
        }
    }
}

@Composable
fun ChatBubble(message: ChatMessage) {
    val isUser = message.sender == "user"
    val alignment = if (isUser) Alignment.End else Alignment.Start
    val bubbleColor = if (isUser) Color(0xFF1E293B) else Color(0xFF0F172A)
    val borderColor = if (isUser) MaterialTheme.colorScheme.primary.copy(alpha = 0.5f) else MaterialTheme.colorScheme.tertiary.copy(alpha = 0.3f)

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = alignment
    ) {
        Box(
            modifier = Modifier
                .widthIn(max = 280.dp)
                .clip(
                    RoundedCornerShape(
                        topStart = 16.dp,
                        topEnd = 16.dp,
                        bottomStart = if (isUser) 16.dp else 0.dp,
                        bottomEnd = if (isUser) 0.dp else 16.dp
                    )
                )
                .background(bubbleColor)
                .border(1.dp, borderColor, RoundedCornerShape(16.dp))
                .padding(12.dp)
        ) {
            Text(
                text = message.text,
                color = Color.White,
                fontSize = 13.sp,
                lineHeight = 18.sp
            )
        }
    }
}

// --- Tab 2: Planner & Notes ---

@Composable
fun PlannerNotesView(viewModel: ZubairViewModel) {
    var plannerSubTab by remember { mutableStateOf(0) } // 0 = Tasks, 1 = Notes/Journal

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        TabRow(
            selectedTabIndex = plannerSubTab,
            containerColor = Color.Transparent,
            contentColor = MaterialTheme.colorScheme.primary,
            modifier = Modifier.fillMaxWidth()
        ) {
            Tab(selected = plannerSubTab == 0, onClick = { plannerSubTab = 0 }) {
                Text("Routine & Tasks", modifier = Modifier.padding(12.dp), fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
            Tab(selected = plannerSubTab == 1, onClick = { plannerSubTab = 1 }) {
                Text("Notes & Journal", modifier = Modifier.padding(12.dp), fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (plannerSubTab == 0) {
            TasksPlannerSubView(viewModel = viewModel)
        } else {
            NotesJournalSubView(viewModel = viewModel)
        }
    }
}

@Composable
fun TasksPlannerSubView(viewModel: ZubairViewModel) {
    val tasks by viewModel.tasks.collectAsStateWithLifecycle()

    var taskTitle by remember { mutableStateOf("") }
    var taskCategory by remember { mutableStateOf("Tasks") }
    var taskPriority by remember { mutableStateOf("Medium") }

    Column(modifier = Modifier.fillMaxSize()) {
        // Add Task Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF10172A))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text("Create New Operating Directive", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.height(8.dp))

                TextField(
                    value = taskTitle,
                    onValueChange = { taskTitle = it },
                    placeholder = { Text("Task Title...") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = TextFieldDefaults.colors(focusedContainerColor = Color(0xFF1E293B), unfocusedContainerColor = Color(0xFF1E293B))
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Category selectors
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf("Routine", "Tasks", "Shopping").forEach { cat ->
                            FilterChip(
                                selected = taskCategory == cat,
                                onClick = { taskCategory = cat },
                                label = { Text(cat, fontSize = 10.sp) }
                            )
                        }
                    }

                    // Priority selectors
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf("High", "Medium", "Low").forEach { prio ->
                            FilterChip(
                                selected = taskPriority == prio,
                                onClick = { taskPriority = prio },
                                label = { Text(prio, fontSize = 10.sp) }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Button(
                    onClick = {
                        if (taskTitle.isNotBlank()) {
                            viewModel.addTask(taskTitle, taskCategory, taskPriority)
                            taskTitle = ""
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("add_task_button")
                        .height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text("Add Objective", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Tasks Scroll Space
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(tasks) { task ->
                TaskRow(
                    task = task,
                    onCheckedChange = { viewModel.toggleTaskCompletion(task) },
                    onDeleteClicked = { viewModel.deleteTask(task) }
                )
            }
        }
    }
}

@Composable
fun NotesJournalSubView(viewModel: ZubairViewModel) {
    val notes by viewModel.notes.collectAsStateWithLifecycle()

    var noteTitle by remember { mutableStateOf("") }
    var noteContent by remember { mutableStateOf("") }
    var noteCategory by remember { mutableStateOf("General") }

    Column(modifier = Modifier.fillMaxSize()) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF10172A))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text("Log Personal Journal / Notes", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.tertiary)
                Spacer(modifier = Modifier.height(8.dp))

                TextField(
                    value = noteTitle,
                    onValueChange = { noteTitle = it },
                    placeholder = { Text("Note Title") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = TextFieldDefaults.colors(focusedContainerColor = Color(0xFF1E293B), unfocusedContainerColor = Color(0xFF1E293B))
                )

                Spacer(modifier = Modifier.height(8.dp))

                TextField(
                    value = noteContent,
                    onValueChange = { noteContent = it },
                    placeholder = { Text("Write content...") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2,
                    colors = TextFieldDefaults.colors(focusedContainerColor = Color(0xFF1E293B), unfocusedContainerColor = Color(0xFF1E293B))
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf("General", "Journal", "Idea").forEach { cat ->
                            FilterChip(
                                selected = noteCategory == cat,
                                onClick = { noteCategory = cat },
                                label = { Text(cat, fontSize = 10.sp) }
                            )
                        }
                    }

                    Button(
                        onClick = {
                            if (noteTitle.isNotBlank() && noteContent.isNotBlank()) {
                                viewModel.addNote(noteTitle, noteContent, noteCategory)
                                noteTitle = ""
                                noteContent = ""
                            }
                        },
                        modifier = Modifier
                            .testTag("add_note_button")
                            .height(40.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary)
                    ) {
                        Text("Save Note", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Notes Scroll Space
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(notes) { note ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column {
                                Text(note.title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
                                Text(note.category, fontSize = 10.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                            }
                            IconButton(onClick = { viewModel.deleteNote(note) }) {
                                Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete Note", tint = Color.Red.copy(alpha = 0.7f))
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(note.content, fontSize = 12.sp, color = Color.White.copy(alpha = 0.8f))
                    }
                }
            }
        }
    }
}

@Composable
fun TaskRow(
    task: Task,
    onCheckedChange: (Boolean) -> Unit,
    onDeleteClicked: (() -> Unit)? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF1E293B))
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
            Checkbox(
                checked = task.isCompleted,
                onCheckedChange = onCheckedChange
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = task.title,
                    fontSize = 13.sp,
                    color = if (task.isCompleted) Color.White.copy(alpha = 0.4f) else Color.White,
                    fontWeight = FontWeight.Bold
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(task.category, fontSize = 9.sp, color = MaterialTheme.colorScheme.primary)
                    Text("•", fontSize = 9.sp, color = Color.Gray)
                    Text("Priority: ${task.priority}", fontSize = 9.sp, color = if (task.priority == "High") Color.Red else Color.Gray)
                }
            }
        }

        if (onDeleteClicked != null) {
            IconButton(onClick = onDeleteClicked) {
                Icon(imageVector = Icons.Default.Delete, contentDescription = "Remove Objective", tint = Color.Red.copy(alpha = 0.6f))
            }
        }
    }
}

// --- Tab 3: Gym & Diet Coach ---

@Composable
fun GymDietView(viewModel: ZubairViewModel) {
    val exerciseLogs by viewModel.exerciseLogs.collectAsStateWithLifecycle()

    var exerciseName by remember { mutableStateOf("") }
    var muscleGroup by remember { mutableStateOf("Chest") }
    var setsInput by remember { mutableStateOf("4") }
    var repsInput by remember { mutableStateOf("12") }
    var weightInput by remember { mutableStateOf("20.0") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Workout Logger Form
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF10172A))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "Track Gym Workout",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    TextField(
                        value = exerciseName,
                        onValueChange = { exerciseName = it },
                        placeholder = { Text("Exercise (e.g. Incline Bench Press)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = TextFieldDefaults.colors(focusedContainerColor = Color(0xFF1E293B), unfocusedContainerColor = Color(0xFF1E293B))
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Muscle Group selection
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        listOf("Chest", "Back", "Legs", "Shoulders", "Arms").forEach { group ->
                            FilterChip(
                                selected = muscleGroup == group,
                                onClick = { muscleGroup = group },
                                label = { Text(group, fontSize = 9.sp) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        TextField(
                            value = setsInput,
                            onValueChange = { setsInput = it },
                            label = { Text("Sets", fontSize = 10.sp) },
                            modifier = Modifier.weight(1f),
                            colors = TextFieldDefaults.colors(focusedContainerColor = Color(0xFF1E293B), unfocusedContainerColor = Color(0xFF1E293B))
                        )
                        TextField(
                            value = repsInput,
                            onValueChange = { repsInput = it },
                            label = { Text("Reps", fontSize = 10.sp) },
                            modifier = Modifier.weight(1f),
                            colors = TextFieldDefaults.colors(focusedContainerColor = Color(0xFF1E293B), unfocusedContainerColor = Color(0xFF1E293B))
                        )
                        TextField(
                            value = weightInput,
                            onValueChange = { weightInput = it },
                            label = { Text("Weight (kg)", fontSize = 10.sp) },
                            modifier = Modifier.weight(1.2f),
                            colors = TextFieldDefaults.colors(focusedContainerColor = Color(0xFF1E293B), unfocusedContainerColor = Color(0xFF1E293B))
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {
                            val sets = setsInput.toIntOrNull() ?: 4
                            val reps = repsInput.toIntOrNull() ?: 12
                            val weight = weightInput.toDoubleOrNull() ?: 20.0
                            if (exerciseName.isNotBlank()) {
                                viewModel.logWorkout(exerciseName, muscleGroup, sets, reps, weight, 60)
                                exerciseName = ""
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text("Log Exercise", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Active workout records title
        item {
            Text(
                text = "Gym Exercise Log History",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = SlateWhite
            )
        }

        if (exerciseLogs.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF161D30))
                ) {
                    Box(modifier = Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                        Text("No logs today. Fuel your discipline, Zubair!", color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp)
                    }
                }
            }
        } else {
            items(exerciseLogs) { log ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(log.exerciseName, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.White)
                            Text("Muscle: ${log.muscleGroup} | Sets: ${log.sets} x ${log.reps} reps @ ${log.weight}kg", fontSize = 11.sp, color = Color.White.copy(alpha = 0.7f))
                        }

                        IconButton(onClick = { viewModel.deleteWorkout(log) }) {
                            Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete log entry", tint = Color.Red.copy(alpha = 0.6f))
                        }
                    }
                }
            }
        }
    }
}

// --- Tab 4: Study Hub & Quizzes ---

@Composable
fun LearningQuizView(viewModel: ZubairViewModel) {
    val quizQuestions by viewModel.currentQuizQuestions.collectAsStateWithLifecycle()
    val activeTopic by viewModel.quizTopic.collectAsStateWithLifecycle()

    var activeQuestionIndex by remember { mutableIntStateOf(0) }
    var selectedAnswerIndex by remember { mutableStateOf<Int?>(null) }
    var currentScore by remember { mutableIntStateOf(0) }
    var quizCompleted by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Study selector buttons
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF10172A))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text("Select Study Track", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("Flutter", "Android Development", "AI").forEach { topic ->
                        FilterChip(
                            selected = activeTopic == topic,
                            onClick = {
                                viewModel.selectQuizTopic(topic)
                                activeQuestionIndex = 0
                                selectedAnswerIndex = null
                                currentScore = 0
                                quizCompleted = false
                            },
                            label = { Text(topic, fontSize = 10.sp) }
                        )
                    }
                }
            }
        }

        // Active Interactive Quiz Panel
        if (quizQuestions.isNotEmpty()) {
            if (!quizCompleted) {
                val q = quizQuestions[activeQuestionIndex]

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.tertiary.copy(alpha = 0.3f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Interactive Daily Challenge", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = MaterialTheme.colorScheme.tertiary)
                            Text("Q: ${activeQuestionIndex + 1}/${quizQuestions.size}", fontSize = 11.sp, color = Color.Gray)
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(q.question, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
                        Spacer(modifier = Modifier.height(12.dp))

                        q.options.forEachIndexed { idx, opt ->
                            val isSelected = selectedAnswerIndex == idx
                            val buttonColor = when {
                                selectedAnswerIndex != null && idx == q.correctAnswerIndex -> Color.Green.copy(alpha = 0.15f)
                                isSelected && idx != q.correctAnswerIndex -> Color.Red.copy(alpha = 0.15f)
                                isSelected -> MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)
                                else -> Color.White.copy(alpha = 0.05f)
                            }
                            val borderCol = when {
                                selectedAnswerIndex != null && idx == q.correctAnswerIndex -> Color.Green
                                isSelected && idx != q.correctAnswerIndex -> Color.Red
                                else -> Color.Transparent
                            }

                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(buttonColor)
                                    .border(1.dp, borderCol, RoundedCornerShape(8.dp))
                                    .clickable(enabled = selectedAnswerIndex == null) {
                                        selectedAnswerIndex = idx
                                        if (idx == q.correctAnswerIndex) {
                                            currentScore += 1
                                        }
                                    }
                                    .padding(12.dp)
                            ) {
                                Text(opt, fontSize = 12.sp, color = Color.White)
                            }
                        }

                        if (selectedAnswerIndex != null) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Text("Explanation: ${q.explanation}", fontSize = 11.sp, color = Color.White.copy(alpha = 0.7f))

                            Spacer(modifier = Modifier.height(12.dp))

                            Button(
                                onClick = {
                                    if (activeQuestionIndex + 1 < quizQuestions.size) {
                                        activeQuestionIndex += 1
                                        selectedAnswerIndex = null
                                    } else {
                                        quizCompleted = true
                                        viewModel.logQuizResult(activeTopic, currentScore, quizQuestions.size)
                                    }
                                },
                                modifier = Modifier.fillMaxWidth().height(48.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                            ) {
                                Text(if (activeQuestionIndex + 1 < quizQuestions.size) "Next Challenge" else "Submit Results", color = Color.Black)
                            }
                        }
                    }
                }
            } else {
                // Completed State
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF10172A))
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("Challenge Complete!", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Zubair, you scored: $currentScore / ${quizQuestions.size}", fontWeight = FontWeight.ExtraBold, fontSize = 22.sp, color = Color.White)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("Your progress has been encrypted and logged offline.", fontSize = 11.sp, color = Color.Gray)

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                activeQuestionIndex = 0
                                selectedAnswerIndex = null
                                currentScore = 0
                                quizCompleted = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Text("Retry Session", color = Color.Black)
                        }
                    }
                }
            }
        }
    }
}

// --- Settings Dialog ---

@Composable
fun SettingsDialog(
    currentLanguage: String,
    onDismiss: () -> Unit,
    onLanguageChanged: (String) -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF10172A)),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Zubair AI Personal Settings",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Select Language Pattern",
                    fontSize = 12.sp,
                    color = Color.White.copy(alpha = 0.7f),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(6.dp))

                listOf("English/Urdu", "Urdu Pure", "Roman Urdu", "English Only").forEach { lang ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onLanguageChanged(lang) }
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(lang, color = Color.White, fontSize = 13.sp)
                        RadioButton(
                            selected = currentLanguage == lang,
                            onClick = { onLanguageChanged(lang) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                Divider(color = Color.White.copy(alpha = 0.1f))
                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "🛡️ Offline Privacy Mode Active",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.tertiary,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "All routines, metrics, and tasks are saved securely on-device with Room Database. No tracking or external analytics are configured.",
                    fontSize = 10.sp,
                    color = Color.White.copy(alpha = 0.5f),
                    textAlign = TextAlign.Center,
                    lineHeight = 14.sp,
                    modifier = Modifier.padding(vertical = 4.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text("Close Diagnostics", color = Color.Black)
                }
            }
        }
    }
}
